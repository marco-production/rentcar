<?php $__env->startSection('content'); ?>
<div class="card position">
    <h4 class="l-login">Login</h4>
    <?php if(session('state')): ?>
       <div class="alert alert-danger"><?php echo e(session('state')); ?></div> 
    <?php endif; ?>
    
    <form class="col-md-12" id="sign_in" method="POST" action="<?php echo e(route('login')); ?>">
        <?php echo csrf_field(); ?>
        <div class="form-group form-float">
            <div class="form-line">
                <input type="email" class="form-control" name="email" autocomplete="email">
                <label class="form-label">Correo electronico</label>
            </div>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" style="color:#dc3545; font-size:12px;" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group form-float">
            <div class="form-line">
                <input type="password" class="form-control" name="password" autocomplete="current-password">
                <label class="form-label">Password</label>
            </div>
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" style="color:#dc3545; font-size:12px;" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
             <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div>
            <input type="checkbox" name="remember" id="rememberme" class="filled-in chk-col-cyan" <?php echo e(old('remember') ? 'checked' : ''); ?>>
            <label for="rememberme">Recordar sesión</label>
        </div>
        <button type="submit" class="btn btn-raised bg-cyan waves-effect">
            Iniciar Sesión
        </button>
        <div class="mt-5">
            <div class="alert alert-secondary">
                <strong>CREDENCIALES</strong><hr>
                <p><span class="label bg-blue">Admin</span><i> admin@hotmail.com</i> <br><span class="label bg-light-green">User</span> <i>user@hotmail.com</i></p>
                <hr>
                <p><span class="label bg-teal">Password</span> 12345678</p>
            </div>
        </div>
        
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\rentcar\resources\views/auth/login.blade.php ENDPATH**/ ?>