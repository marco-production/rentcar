<?php $__env->startSection('css'); ?>
    <!-- Bootstrap Core Css -->
    <link href="<?php echo e(asset('plugins/bootstrap/css/bootstrap.css')); ?>" rel="stylesheet">

    <!-- Waves Effect Css -->
    <link href="<?php echo e(asset('plugins/node-waves/waves.css')); ?>" rel="stylesheet" />

    <!-- Animation Css -->
    <link href="<?php echo e(asset('plugins/animate-css/animate.css')); ?>" rel="stylesheet" />

    <!-- Colorpicker Css -->
    <link href="<?php echo e(asset('plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.css')); ?>" rel="stylesheet" />

    <!-- Dropzone Css -->
    <link href="<?php echo e(asset('plugins/dropzone/dropzone.css')); ?>" rel="stylesheet">

    <!-- Multi Select Css -->
    <link href="<?php echo e(asset('plugins/multi-select/css/multi-select.css')); ?>" rel="stylesheet">

    <!-- Bootstrap Spinner Css -->
    <link href="<?php echo e(asset('plugins/jquery-spinner/css/bootstrap-spinner.css')); ?>" rel="stylesheet">

    <!-- Bootstrap Tagsinput Css -->
    <link href="<?php echo e(asset('plugins/bootstrap-tagsinput/bootstrap-tagsinput.css')); ?>" rel="stylesheet">

    <!-- Bootstrap Select Css -->
    <link href="<?php echo e(asset('plugins/bootstrap-select/css/bootstrap-select.css')); ?>" rel="stylesheet" />

    <!-- noUISlider Css -->
    <link href="<?php echo e(asset('plugins/nouislider/nouislider.min.css')); ?>" rel="stylesheet" />

    <!-- Custom Css -->
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">

    <!-- AdminBSB Themes. You can choose a theme from css/themes instead of get all themes -->
    <link href="<?php echo e(asset('css/themes/all-themes.css')); ?>" rel="stylesheet" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <basic-crud-component api_url="/tipovehiculo" model_name="tipo de vehiculo" genero="El"></basic-crud-component>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>

    <script src="<?php echo e(asset('plugins/jquery/jquery.min.js')); ?>"></script>

    <!-- Bootstrap Core Js -->
    <script src="<?php echo e(asset('plugins/bootstrap/js/bootstrap.js')); ?>"></script>

    <!-- Select Plugin Js -->
    <script src="<?php echo e(asset('plugins/bootstrap-select/js/bootstrap-select.js')); ?>"></script>

    <!-- Slimscroll Plugin Js -->
    <script src="<?php echo e(asset('plugins/jquery-slimscroll/jquery.slimscroll.js')); ?>"></script>

    <!-- Bootstrap Colorpicker Js -->
    <script src="<?php echo e(asset('plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.js')); ?>"></script>

    <!-- Dropzone Plugin Js -->
    <script src="<?php echo e(asset('plugins/dropzone/dropzone.js')); ?>"></script>

    <!-- Input Mask Plugin Js -->
    <script src="<?php echo e(asset('plugins/jquery-inputmask/jquery.inputmask.bundle.js')); ?>"></script>

    <!-- Multi Select Plugin Js -->
    <script src="<?php echo e(asset('plugins/multi-select/js/jquery.multi-select.js')); ?>"></script>

    <!-- Jquery Spinner Plugin Js -->
    <script src="<?php echo e(asset('plugins/jquery-spinner/js/jquery.spinner.js')); ?>"></script>

    <!-- Bootstrap Tags Input Plugin Js -->
    <script src="<?php echo e(asset('plugins/bootstrap-tagsinput/bootstrap-tagsinput.js')); ?>"></script>

    <!-- noUISlider Plugin Js -->
    <script src="<?php echo e(asset('plugins/nouislider/nouislider.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/bootstrap-notify/bootstrap-notify.js')); ?>"></script>
    <!-- Waves Effect Plugin Js -->
    <script src="<?php echo e(asset('plugins/node-waves/waves.js')); ?>"></script>

    <!-- Custom Js -->
    <script src="<?php echo e(asset('js/admin.js')); ?>"></script>
    <script src="<?php echo e(asset('js/pages/forms/advanced-form-elements.js')); ?>"></script>
    <script src="<?php echo e(asset('js/pages/ui/modals.js')); ?>"></script>
    <!-- Demo Js -->
    <script src="<?php echo e(asset('js/demo.js')); ?>"></script>
    <script>
        $( document ).ready(function() {
            $('html, body').animate({scrollTop:0}, 'slow');
            $('.label-up').click(function(){  //referimos el elemento ( clase o identificador de acción )
                $('html, body').animate({scrollTop:0}, 'slow'); //seleccionamos etiquetas,clase o identificador destino, creamos animación hacia top de la página.
                return false;
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\rentcar\resources\views/empleado/tipovehiculo.blade.php ENDPATH**/ ?>