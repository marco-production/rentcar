<?php $__env->startSection('css'); ?>
    <!-- Bootstrap Core Css -->
    <link href="<?php echo e(asset('plugins/bootstrap/css/bootstrap.css')); ?>" rel="stylesheet">

    <!-- Waves Effect Css -->
    <link href="<?php echo e(asset('plugins/node-waves/waves.css')); ?>" rel="stylesheet" />

    <!-- Animation Css -->
    <link href="<?php echo e(asset('plugins/animate-css/animate.css')); ?>" rel="stylesheet" />

    <!-- Morris Chart Css-->
    <link href="<?php echo e(asset('plugins/morrisjs/morris.css')); ?>" rel="stylesheet" />

    <!-- Custom Css -->
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">

    <!-- AdminBSB Themes. You can choose a theme from css/themes instead of get all themes -->
    <link href="<?php echo e(asset('css/themes/all-themes.css')); ?>" rel="stylesheet" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="block-header">
        <h2>PERFIL DE USUARIO</h2>
    </div>
    <?php if(session('status')): ?>
        <div class="alert bg-green alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>
    <!-- Body Copy -->
    <div class="row clearfix">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="card">
                <div class="header">
                    <h2>
                        <?php echo e($user->full_name); ?>

                    </h2>
                    <ul class="header-dropdown m-r--5">
                        <li class="dropdown">
                            <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                <i class="material-icons">more_vert</i>
                            </a>
                            <ul class="dropdown-menu pull-right">
                                <li><a href="<?php echo e(url('/')); ?>">Lista de usuarios</a></li>
                                <li><a href="<?php echo e(route('edit-user',$user->slug)); ?>">Editar</a></li>
                                <li>
                                    <a href="#" onclick="if(confirm('¿Deseas eliminar este usuario?')){document.getElementById('form').submit();}">Eliminar</a>
                                    <form action="/user/<?php echo e($user->slug); ?>" method="POST" id="form" style="display: contents;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                    </form>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>
                <div class="body">
                    <div class="row clearfix">
                        <div class="col-sm-3">
                            <img src="<?php echo e(asset('images/big-img.png')); ?>" width="200" height="200" style="border-radius:10px;" alt="User" />
                        </div>
                        <div class="col-sm-4">
                            <p><b>Nombre completo:</b> <?php echo e($user->full_name); ?></p>
                            <p><b>Correo electrónico:</b> <?php echo e($user->email); ?></p>
                            <p><b>Cédula:</b> <?php echo e($user->cedula); ?></p>
                            <p><b>Tipo de usuario:</b> <?php if($user->role_id == 1): ?><span class="label bg-black">Administrador</span><?php else: ?><span class="label bg-blue-grey">Empleado</span><?php endif; ?></p>
                        </div>
                        <div class="col-sm-3">
                            <p><b>Tanda laboral:</b> <?php $__currentLoopData = explode(",",$user->tanda); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($item); ?> <?php if(!$loop->last): ?>,<?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></p>
                            <p><b>Comisión:</b> <?php echo e($user->comision); ?></p>
                            <p><b>Fecha de ingreso:</b> <?php echo e($user->fecha_ingreso); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
   <!-- Jquery Core Js -->
   <script src="<?php echo e(asset('plugins/jquery/jquery.min.js')); ?>"></script>

   <!-- Bootstrap Core Js -->
   <script src="<?php echo e(asset('plugins/bootstrap/js/bootstrap.js')); ?>"></script>

   <!-- Select Plugin Js -->
   <script src="<?php echo e(asset('plugins/bootstrap-select/js/bootstrap-select.js')); ?>"></script>

   <!-- Slimscroll Plugin Js -->
   <script src="<?php echo e(asset('plugins/jquery-slimscroll/jquery.slimscroll.js')); ?>"></script>

   <!-- Waves Effect Plugin Js -->
   <script src="<?php echo e(asset('plugins/node-waves/waves.js')); ?>"></script>

   <!-- Jquery CountTo Plugin Js -->
   <script src="<?php echo e(asset('plugins/jquery-countto/jquery.countTo.js')); ?>"></script>

   <!-- Morris Plugin Js -->
   <script src="<?php echo e(asset('plugins/raphael/raphael.min.js')); ?>"></script>
   <script src="<?php echo e(asset('plugins/morrisjs/morris.js')); ?>"></script>

   <!-- ChartJs -->
   <script src="<?php echo e(asset('plugins/chartjs/Chart.bundle.js')); ?>"></script>

   <!-- Flot Charts Plugin Js -->
   <script src="<?php echo e(asset('plugins/flot-charts/jquery.flot.js')); ?>"></script>
   <script src="<?php echo e(asset('plugins/flot-charts/jquery.flot.resize.js')); ?>"></script>
   <script src="<?php echo e(asset('plugins/flot-charts/jquery.flot.pie.js')); ?>"></script>
   <script src="<?php echo e(asset('plugins/flot-charts/jquery.flot.categories.js')); ?>"></script>
   <script src="<?php echo e(asset('plugins/flot-charts/jquery.flot.time.js')); ?>"></script>

   <!-- Sparkline Chart Plugin Js -->
   <script src="<?php echo e(asset('plugins/jquery-sparkline/jquery.sparkline.js')); ?>"></script>

   <!-- Custom Js -->
   <script src="<?php echo e(asset('js/admin.js')); ?>"></script>
   <script src="<?php echo e(asset('js/pages/index.js')); ?>"></script>

   <!-- Demo Js -->
   <script src="<?php echo e(asset('js/demo.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\rentcar\resources\views/user/show.blade.php ENDPATH**/ ?>